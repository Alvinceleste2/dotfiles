-- Neovim config written in Lua
--
-- Author: Rodrigo
        
require('general_config')
require('keymaps')
require('clang-format')
require('latex-indent')
require('plugins')
require('plugin_config')


