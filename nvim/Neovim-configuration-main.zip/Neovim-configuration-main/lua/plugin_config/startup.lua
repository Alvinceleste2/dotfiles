-- Startup screen
require'startup'.setup()
