-- Color theme
vim.o.termguicolors = true
vim.cmd [[colorscheme gruvbox]]
