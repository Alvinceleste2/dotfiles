-- <leader>mm opens firefox with markdown preview in real time
vim.keymap.set('n', '<leader>mm', ':MarkdownPreview<CR>')
vim.g.mkdp_auto_close = 0
